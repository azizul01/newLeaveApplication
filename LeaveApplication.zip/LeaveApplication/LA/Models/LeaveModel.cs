﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using DAL.db;
namespace LA.Models
{
    public class LeaveModel
    {
        //-------------- Start:: Class Model List Declare --------------
        public List<leaveinfo> Listleaveinfo { get; set; }
        public List<leaveassign> Listleaveassign { get; set; }
        //------------- End:: Class Model List Declare ------------ 

        //----------- Start:: Class Model Object Declare ----------
        public virtual leaveinfo objleaveinfo { get; set; }
        public virtual leaveassign objleaveassign { get; set; }
        //----------- End:: Class Model Object Declare ----------
    }
}