﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;  
using System.Data;
using DAL.db;
using BAL.LeaveAssign;
using DAL.Common;
using LA.Models;
using System.Net.Mail;
using System.Data.Entity;


namespace LA.Controllers
{
    public class leave_applicationController : Controller
    {
        LeaveApplyEntities db = new LeaveApplyEntities();
        DBLeaveAssign objDBLeaveAssign = new DBLeaveAssign();
        DBLeaveApplyInfo objDBLeaveApplyInfo = new DBLeaveApplyInfo();
        public bool isCompleted = false;
        public bool sMessage = false;



        //************************* Start:: Leave Apply **************************
        #region
        //--------------------------- Start:: Function --------------------------- 
        [HttpPost]
        public JsonResult FxLeaveApplySubmit(leave_applyinfo objleave_applyinfo)
        {
            int i = -1;
            
            if (!ModelState.IsValid)
            {
                return Json(new { isCompleted = isCompleted, Errors = Function.FillModelStateError(ModelState) }, JsonRequestBehavior.AllowGet);
            }

            try
            {
                if (objleave_applyinfo.leave_apply_id > 0)
                {
                    i = objDBLeaveApplyInfo.Update(objleave_applyinfo);
                    isCompleted = true;
                }
                else
                {
                    //objleave_applyinfo.leave_apply_id = 1;
                    i = objDBLeaveApplyInfo.Insert(objleave_applyinfo);
                    isCompleted = true;
                }
            }
            catch (Exception E)
            {
                i = -1;
                isCompleted = false;
            }
            return Json(new { isCompleted = isCompleted }, JsonRequestBehavior.AllowGet);
        }

        public JsonResult FillLeaveInfo(int sEmpId, string sLeaveType)
        {
            var model = (dynamic)(null);
            if (sEmpId > 0)
            {
                model = (from li in db.leaveinfoes
                         where li.empid == sEmpId && li.leavetype == sLeaveType
                         select new
                         {
                             ldate = li.ldate,
                             leavetype = li.leavetype
                         }).ToList();
                if (model.Count > 0)
                {
                    isCompleted = true;
                }
                else
                {
                    isCompleted = true;
                }
            }
            return new JsonResult { Data = new { isCompleted = isCompleted, LeaveInfo = model } };
        }

        //---------------------------- End:: Function ---------------------------- 


        //------------------------- Start:: ActionResult -------------------------
        public ActionResult leave_applicatio_create()
        {
            //SELECT li.empid, li.leavetype, la.AssignDays - Count(li.leavetype) AvailableDays  , Count(li.leavetype) EnjoyDays, la.AssignDays  
            //FROM leaveinfo li INNER JOIN leaveassign la ON li.leavetype = la.LeaveType 
            //Where empid = 3 and ldate between '2016-01-01' And '2016-12-31' group by li.leavetype, li.empid, la.AssignDays


            //var model = (from li in db.leaveinfoes
            //             join la in db.leaveassigns on li.leavetype equals la.LeaveType
            //             where li.empid == 3
            //             select new LeaveModel
            //         {
            //             objleaveinfo = li,
            //             objleaveassign = la
            //         }).ToList();

            //var model = (from e in db.emps
            //             join dep in db.depts on Convert.ToInt32(e.DEPT_CODE) equals dep.sid
            //             join deg in db.desigs on Convert.ToInt32(e.DESI_CODE) equals deg.sid
            //             where e.EMPID == 6
            //             select new {
            //                 EMPID = e.EMPID,
            //                 DEPT_CODE = 
                         
            //             }).ToList();


            var model = db.emps.Where(p => p.EMPID == 6).ToList();
            ViewBag.empid = model[0].EMPID.ToString();
            ViewBag.empname = model[0].NAME.ToString();
            int DESI_CODE = Convert.ToInt32(model[0].DESI_CODE.ToString());
            int DEPT_CODE = Convert.ToInt32(model[0].DEPT_CODE.ToString());

            ViewBag.cboDesignation = new SelectList(db.desigs.Where(p => p.sid == DESI_CODE), "sid", "desi", DESI_CODE);

            //ViewBag.cboDesignation = new SelectList(db.desigs, "sid", "desi", Convert.ToInt32(model[0].DESI_CODE));

            ViewBag.cboDepartment = new SelectList(db.depts.Where(dep => dep.sid == DEPT_CODE), "sid", "dept_name", DEPT_CODE); 

            //ViewBag.cboDepartment = new SelectList(db.depts, "sid", "dept_name"); 

            return View();
        }
        //-------------------------- End:: ActionResult -------------------------- 
        #endregion

        //************************** End:: Leave Apply ***************************



        //******************** Start:: Leave Apply Approval **********************
        #region 
        
        //--------------------------- Start:: Function ---------------------------
        public JsonResult FillEmailInfo(int sEmpId)
        {
            var model = (dynamic)(null);
            if (sEmpId > 0)
            {
                model = (from e in db.emps
                         where e.EMPID == sEmpId 
                         select new
                         {
                             EMAIL = e.EMAIL 
                         }).ToList();
                if (model.Count > 0)
                {
                    isCompleted = true;
                }
                else
                {
                    isCompleted = true;
                }
            }
            return new JsonResult { Data = new { isCompleted = isCompleted, EmailInfo = model } };
        }

        [HttpPost]
        public JsonResult FxConfirmationLeaveApply(string sActionFlag, string sTo, string sFrom, string sSubject, string sBody, int sleave_apply_id)
        {
            // Document Status 0 = Draft, 1 = Approval And 2 = Canceled
            int i = -1;
            int sdocument_status = -1;

            if (sActionFlag == "Approved")
            {
                leave_applyinfo objLeave_applyinfo = db.leave_applyinfo.Find(sleave_apply_id);
                objLeave_applyinfo.document_status = 1;

                db.Entry(objLeave_applyinfo).State = System.Data.Entity.EntityState.Modified;
                i = db.SaveChanges();

                sdocument_status = 1;
            }

            if (sActionFlag == "Cancel")
            {
                leave_applyinfo objLeave_applyinfo = db.leave_applyinfo.Find(sleave_apply_id);
                objLeave_applyinfo.document_status = 2;

                db.Entry(objLeave_applyinfo).State = System.Data.Entity.EntityState.Modified;
                i = db.SaveChanges();

                sdocument_status = 2;
            }


            MailMessage mail = new MailMessage();
            mail.To.Add(sTo);
            mail.From = new MailAddress(sFrom);
            mail.Subject = sSubject;
            string Body = sBody;
            mail.Body = Body;
            mail.IsBodyHtml = true;
            SmtpClient smtp = new SmtpClient();
            smtp.Host = "smtp.gmail.com";
            smtp.Port = 587;
            smtp.UseDefaultCredentials = false;
            smtp.Credentials = new System.Net.NetworkCredential("mdazizulhoque.bd@gmail.com", "AzizuLhuq.gmail01");// Enter seders User name and password
            smtp.EnableSsl = true;
            smtp.Send(mail);

            return new JsonResult { Data = new { isCompleted = true, document_status = sdocument_status, leave_apply_id = sleave_apply_id } };
        }

        //---------------------------- End:: Function ---------------------------- 

        //------------------------- Start:: ActionResult -------------------------
        public ActionResult leave_applicatio_approval()
        {
            var model = db.emps.Where(p => p.EMPID == 11).ToList();
            ViewBag.To = model[0].EMAIL.ToString();
            return View(db.leave_applyinfo.ToList());
        }
        //-------------------------- End:: ActionResult -------------------------- 
        #endregion
        //****************** End:: Leave Application Approval ********************

        //************************* Start:: Leave Assign *************************
        #region
        //--------------------------- Start:: Function ---------------------------

        public void FrmLeaveAssignDefaultLoad()
        {
            ViewBag.CallingForm = this.ControllerContext.RouteData.Values["controller"].ToString(); ;
            ViewBag.CallingForm1 = "Leave Assign";
            ViewBag.CallingForm2 = "Add New";
            ViewBag.CallingViewPage = "/leave_application/leave_assign_create";

            ViewBag.btnVsbSubmit = "visibility: hidden";
            ViewBag.btnVsbSave = "visibility: hidden";
        }

        [HttpPost]
        public JsonResult FxLeaveAssignSubmit(leaveassign LeaveAssign)
        {
            int i = -1;

            if (!ModelState.IsValid)
            {
                return Json(new { isCompleted = isCompleted, Errors = Function.FillModelStateError(ModelState) }, JsonRequestBehavior.AllowGet);
            }

            var LeaveTypeExists = db.leaveassigns.Where(p => p.LeaveType == LeaveAssign.LeaveType).ToList();
            if (LeaveTypeExists.Count > 0)
            {
                return Json(new { isCompleted = isCompleted, sMessage = "Leave Type already exists." }, JsonRequestBehavior.AllowGet);
            }

            try
            {
                if (LeaveAssign.LeaveAssignId > 0)
                {
                    i = objDBLeaveAssign.Update(LeaveAssign);
                }
                else
                {
                    i = objDBLeaveAssign.Insert(LeaveAssign);
                }

                if (i > -1)
                {
                    isCompleted = true;
                }
                else
                {
                    isCompleted = false;
                }
            }
            catch (Exception E)
            {
                isCompleted = false;
            }
            return Json(new { isCompleted = isCompleted }, JsonRequestBehavior.AllowGet);
        }
        //---------------------------- End:: Function ---------------------------- 


        //------------------------- Start:: ActionResult ------------------------- 
        public ActionResult leave_assign()
        {
            return View(db.leaveassigns.ToList());
        } 
        public ActionResult leave_assign_create(int? id)
        {
            FrmLeaveAssignDefaultLoad();

            ViewBag.cboStatus = "0";

            if (id == null)
            {
                ViewBag.btnVsbSubmit = "visibility: visible";
                return View();
            }

            leaveassign objleaveassign = new leaveassign();
            objleaveassign = db.leaveassigns.Find(id);

            if (objleaveassign == null)
            {
                ViewBag.btnVsbSave = "visibility: visible";
                return View();
            }
            else
            {
                ViewBag.CallingForm2 = "Edit";
                ViewBag.btnVsbSubmit = "visibility: hidden";
                ViewBag.btnVsbSave = "visibility: visible";
                ViewBag.cboStatus = objleaveassign.AssignStatus;

                return View(objleaveassign);
            }
        }

        //-------------------------- End:: ActionResult -------------------------- 
        #endregion
        //************************** End:: Leave Assign **************************


    }
}