﻿$(document).ready(function () { 
    // Textbox Change:: Error validation control Add & Remove
    $('.form-control').bind('input', function () {
        $(this).next('.ibserror').hide();
        $(this).next().next('.ibserror').hide();

        $(this).siblings().children('.ibserror').hide();//added 1.11.16

        if ($(this).next('.ibserror').text() != "" && $(this).val().length == 0)
            $(this).parent().parent().addClass('has-error');
        else
            $(this).parent().parent().removeClass('has-error');
    });



    // Dropdown Selected Value:: Error validation control Hide when Dropdown Selected Item Change
    $("select").change(function () {
        if ($(this).val() != '') {
            $(this).parent().nextAll('.ibserror').hide();

            $(this).parent().parent().nextAll('.ibserror').hide();
            $(this).parent().next('.ibserror').hide();

            $(this).siblings().children('.ibserror').hide();//added 1.11.16
            
        }
        else {
            $(this).parent().nextAll('.ibserror').show();
        }
    }).change();



    // Datetimepicker:: Error validation control Hide when datepicker date Change
    $(document).on('change', '#datepicker-component', function () {
        $(this).next('.ibserror').hide();
        $(this).next().next('.ibserror').hide();
    });



    //Server side:: Error validation control add Error class
    if ($('.field-validation-error').text() != "") {
        $('.field-validation-error').parent().parent().parent().addClass('has-error');
    }



    //Textbox Change:: Error validation control text remove
    $(".input-validation-error").keyup(function () {
        $(".input-validation-error").next(".field-validation-error").html('');
    });

    // Load Event:: Error validation control Hide
    $('.ibserror').hide();


    //Added by kamrul 06.09.2016
    $(".IsNumber").keydown(function (e) {
        // Allow: backspace, delete, tab, escape, enter and .
        if ($.inArray(e.keyCode, [46, 8, 9, 27, 13, 110, 190]) !== -1 ||
            // Allow: Ctrl+A
            (e.keyCode == 65 && e.ctrlKey === true) ||
            // Allow: home, end, left, right
            (e.keyCode >= 35 && e.keyCode <= 39)) {
            // let it happen, don't do anything
            return;
        }
        // Ensure that it is a number and stop the keypress
        if ((e.shiftKey || (e.keyCode < 48 || e.keyCode > 57)) && (e.keyCode < 96 || e.keyCode > 105)) {
            e.preventDefault();
        }
    });

    $(".thousandSeperate").keyup(function (e) {
        //function addCommas(nStr) {
        var id = e.target.id;
        var nStr = $('#' + id).val();
        nStr = nStr.replace(/,/g, '');
        nStr += '';
        x = nStr.split('.');
        x1 = x[0];
        x2 = x.length > 1 ? '.' + x[1] : '';
        var rgx = /(\d+)(\d{3})/;
        while (rgx.test(x1)) {
            x1 = x1.replace(rgx, '$1' + ',' + '$2');
        }
        //return $(this).val(x1 + x2);
        $('#' + id).val(x1 + x2);
        //return x1 + x2;
    })

});

//When Submit / Edit Successful then page full refresh.
function clear(controllers, functionname) {
    setTimeout(function () {
        window.location.href = '/' + controllers + '/' + functionname;
    }, 1000);
}

//Date Formate 
function date(value) {
    var monthNames = ["Jan", "Feb", "Mar", "Apr", "May", "Jun",
                      "July", "Aug", "Sep", "Oct", "Nov", "Dec"];
    var pattern = /Date\(([^)]+)\)/;
    var results = pattern.exec(value);
    var dt = new Date(parseFloat(results[1]));
    return (("0" + (dt.getDay())).slice(-2) + "-" + monthNames[dt.getMonth() + 1]) + "-" + dt.getFullYear();
}

//$("#btnClear").click(function () {
//    window.location.href = '/basic/frmchart_of_accounts';
//});


//Added by kamrul 06.09.2016
function validFromDateToDate(fromDateName, toDateName, fromDateID, toDateID, changeTxtName) {
    if (changeTxtName == 'fromDate') {
        var fromDate = $("#" + fromDateID).datepicker("getDate");
        var toDate = $("#" + toDateID).datepicker("getDate");
        if (toDate != "") {
            if (fromDate > toDate) {
                alert(fromDateName + ' Must Be Less Than ' + toDateName + '');
                $("#" + fromDateID).val('');
                return;
            }
        }
    }
    if (changeTxtName == 'toDate') {
        var fromDate = $("#" + fromDateID).datepicker("getDate");
        var toDate = $("#" + toDateID).datepicker("getDate");
        if (fromDate != "") {
            if (fromDate > toDate) {
                alert(toDateName + ' Must Be Greater Than ' + fromDateName + '');
                $("#" + fromDateID).val('');
                return;
            }
        }
    }
}


//Added by kamrul 22.09.2016
function showOkAlert(message, titleMsg) {
    new Function(
    $.prompt(message, {
        title: titleMsg,
        buttons: { "Ok": true },
        submit: function (e, v, m, f) {
            return v;
            //if (v == true) {
            //    return
            //}
        }
    })
  )
}

////Added by kamrul 22.09.2016
//function showConfirmAlert(message, titleMsg) {
//    new Function(
//    $.prompt(message, {
//        title: titleMsg,
//        buttons: { "Ok": true, "Cancel": false },
//        submit: function (e, v, m, f) {
//            return v;
//        }
//    })
//  )
//}

//Start::  Message showing Functions

//Success Operation
function ShowCustomOpMessage(sMessage, title) {
    $.prompt(sMessage, {
        title: title,
        buttons: { "Ok": true },
        submit: function (e, v, m, f) {
            return;
        }
    })
    $(".jqititle").css({ "color": "#0a7c71", "background-color": "#cff5f2", "border-color": "#0a7c71" });
}

function ShowCustomOpMessage1(sMessage, title) {
    $.prompt(sMessage, {
        title: title,
        buttons: { "Ok": true },
        submit: function (e, v, m, f) {
            return;
        }
    })
    $(".jqititle").css({ "color": "#957d32", "background-color": "#fef6dd", "border-color": "#957d32" });
}

//Success Operation
function ShowOpMessage(sOperation, IsSuccess, sFunctionName) {
    if (IsSuccess) {
        $.prompt(sOperation + " Operation Successful.", {
            title: "Success",
            buttons: { "Ok": true },
            submit: function (e, v, m, f) {
                eval(sFunctionName + "(" + v + ")");
            }
        })

        $(".jqititle").css({ "color": "#0a7c71", "background-color": "#cff5f2", "border-color": "#0a7c71" });
    }
    else {
        $.prompt(sOperation + " Operation Failed!", {
            title: "Failed",
            buttons: { "Ok": true },
            submit: function (e, v, m, f) {
                //eval(sFunctionName + "(" + v + ")");
            }
        })

        $(".jqititle").css({ "color": "#933432", "background-color": "#fddddd", "border-color": "#933432" });
    }
}
 
//No Record Operation
function ShowNoRecord() {
    $.prompt("Sorry, Data not found!", {
        title: "Warning",
        buttons: { "Ok": true },
        submit: function (e, v, m, f) {
            //eval(sFunctionName + "(" + v + ")"); 
            return;
        }
    })

    $(".jqititle").css({ "color": "#933432", "background-color": "#fddddd", "border-color": "#933432" });
}

//Delete Operation
function ShowConfirmDeletion(sFunctionName) {
    $.prompt("Sure to DELETE this record?", {
        title: "Confirmation",
        buttons: { "Yes": true, "No": false },
        submit: function (e, v, m, f) {
            eval(sFunctionName + "(" + v + ")");
        }
    })
    $(".jqititle").css({ "color": "#957d32", "background-color": "#fef6dd", "border-color": "#957d32" });
}

//confirmation Operation
function ShowOKCANCELConfirmation(sFunctionName) {
    $.prompt("Sure to DELETE this record?", {
        title: "Confirmation",
        buttons: { "Ok": true, "Cancel": false },
        submit: function (e, v, m, f) {
            eval(sFunctionName + "(" + v + ")");
        }
    })
    $(".jqititle").css({ "color": "#957d32", "background-color": "#fef6dd", "border-color": "#957d32" });
}
 
//Information Operation
function ShowInfoMsg(message) {
    $('body').pgNotification({
        style: 'circle',
        title: 'Warning',
        message: message,
        position: "bottom-right",
        timeout: 0,
        type: "danger",
        showClose: !0,
        onShown: function () { },
        onClosed: function () { },
        thumbnail: '<img width="40" height="40" style="display: inline-block;" src="/Content/built_in/assets/img/profiles/info.png" data-src="/Content/built_in/assets/img/profiles/info.png" data-src-retina="/Content/built_in/assets/img/profiles/info.png" alt="">'
    }).show();
}

//Warning Operation
function ShowWarningMsg(message) {
    $('body').pgNotification({
        style: 'circle',
        title: 'Warning',
        message: message,
        position: "bottom-right",
        timeout: 0,
        type: "danger",
        showClose: !0,
        onShown: function () { },
        onClosed: function () { },
        thumbnail: '<img width="40" height="40" style="display: inline-block;" src="/Content/built_in/assets/img/profiles/info.png" data-src="/Content/built_in/assets/img/profiles/info.png" data-src-retina="/Content/built_in/assets/img/profiles/info.png" alt="">'
    }).show();
}

//Permission Operation
function ShowPermissionMsg(message, titleMsg, sFunctionName) {
    new Function(
    $.prompt(message, {
        title: titleMsg,
        buttons: { "Ok": true },
        submit: function (e, v, m, f) {
            eval(sFunctionName + "(" + v + ")");
        }
    })
  )
}
 
//End::  Message showing Functions









